
#include <iostream.h>
#include <string.h>
#include <afxwin.h>
#include <vector>
using namespace std;

#define N 400000
#define M 100
#define D 50
struct node
{
	int name;
	int min_root,max_root;
	vector <int> parent;
	vector <int> children;
	bool used;
	bool toroot;//�ִ�����
	bool toleave;
	int Npath[D];//�ڵ�����·������
	int LNpath[D];
	int PNpath[D];//���ƶ�Լ��ΪDʱ��Ԥ�����ڵ�����·������
	int LeafApprox;
	bool UpdateN;
};

char S[N];
struct sub_ptn_struct
{
	char start,end;		//
	int min,max;		//
};
struct occurrence
{
	vector <int > position;
};
vector <occurrence> store;
sub_ptn_struct sub_ptn[M];  //pattern p[i]
int ptn_len=0;  //the length of pattern-1=����-1=����±�ֵ
int seq_len=0;
int maxgap=-1;


void createnettree(vector <node> *nettree,int T)
{
	for (int i=0;i<ptn_len+1;i++)
		nettree[i].resize (0);//�������ʼ��
	int *start;
	start=new int[ptn_len+1];
	for (i=0;i<ptn_len+1;i++)
		start[i]=0;
	for (i=0;i<strlen(S);i++)
	{
		//��ÿ���ַ���һ���
		//�Խ����г�ʼ����
		node anode;
		anode.name =i;
		anode.parent.resize (0);
		anode.children .resize (0);
		anode.used =false;//û��ʹ��Ϊ�٣�ʹ��Ϊ��
	    anode.UpdateN=false;
		for(int h=0;h<T+1;h++)
			anode.Npath[h]=0;
		
	    if(i<strlen(S)-ptn_len+1)
		{
			//ֱ�Ӵ洢�ý����Ϊ������
			int len=nettree[0].size ();
			nettree[0].resize (len+1);
			anode.toroot =true;
			nettree[0][len]=anode;
			
            //���������ڵ�����·����
			if(sub_ptn[0].start ==S[i])
			{        nettree[0][len].Npath[0]=1;
			         for(int h=1;h<T+1;h++){nettree[0][len].Npath[h]=0;}
			}
			else {   nettree[0][len].Npath[0]=0;
			         nettree[0][len].Npath[1]=1;
			         for(int h=2;h<T+1;h++){nettree[0][len].Npath[h]=0;}
			}
            

		}
		for (int j=0;j<ptn_len;j++)
		{
				//��һ������˫��
				int prev_len=nettree[j].size ();
				if (prev_len==0)
				{
					//˵�����޽�㣬�����˳�
					break;
				}
				//�������  ������
				for (int k=start[j];k<prev_len;k++)
				{
					int name=nettree[j][k].name;
					if (i-nettree[j][k].name -1>sub_ptn[j].max )
					{
						//��������Ͻ죬�α����
						start[j]++;
					}
				}
				//�жϼ�϶Լ��
				if (i-nettree[j][prev_len-1].name -1>sub_ptn[j].max)
				{
					//����������϶Լ��
					continue;
				}
				if (i-nettree[j][start[j]].name -1<sub_ptn[j].min)
				{
					continue;
				}
	
				int len=nettree[j+1].size ();
				nettree[j+1].resize (len+1);
				anode.toroot =true;
				nettree[j+1][len]=anode;
				for (k=start[j];k<prev_len;k++)
				{
					//�ж��Ƿ������϶Լ��
					int name=nettree[j][k].name;
					if (i-nettree[j][k].name -1>sub_ptn[j].max )
					{
						//��������Ͻ죬�α����
						start[j]++;
						continue;
					}
					if (i-nettree[j][k].name -1<sub_ptn[j].min )
					{
						//��������½磬�˳�
						break;
					}
					//�����϶Լ������ʼ�ж��Ƿ�������ƾ�����ֵ
                    if(sub_ptn[j].end==S[i]){
					      for(int h=0;h<T+1;h++){
					     	nettree[j+1][len].PNpath[h]=nettree[j][k].Npath[h];}
				    	
					}
					else{ nettree[j+1][len].PNpath[0]=0;
					      for(int h=1;h<T+1;h++){
					     	nettree[j+1][len].PNpath[h]=nettree[j][k].Npath[h-1];}
					}
			
					bool notAllZero = false;
                    for(int h=0;h<T+1;h++) {
                         if(nettree[j+1][len].PNpath[h]!=0) {
                                 notAllZero = true;break;
						 }
					}
                    if(!notAllZero)  continue;
					
                    
					//�ڼ�϶Լ��֮�䣬������ƾ���Լ��
					//�������ӹ�ϵ
					int nc=nettree[j][k].children .size ();
					nettree[j][k].children.resize (nc+1);
					nettree[j][k].children [nc]=len;//�洢λ��
					int np=nettree[j+1][len].parent .size ();
					nettree[j+1][len].parent.resize (np+1);
					nettree[j+1][len].parent [np]=k;
               
					//��ʼ����������Ҷ��·������ Npath[h]  
					if(sub_ptn[j].end==S[i]){       	//��ȷƥ�䵱ǰ�ڵ��·����=���ڵ��·�������� 
			              
						for(int h=0;h<T+1;h++)
                            nettree[j+1][len].Npath[h]=nettree[j+1][len].Npath[h]+nettree[j][k].Npath[h];
                  
					}
					else  { 
					         
						    nettree[j+1][len].Npath[0]=nettree[j+1][len].Npath[0];
				    	for(int h=1;h<T+1;h++)
                            nettree[j+1][len].Npath[h]=nettree[j+1][len].Npath[h]+nettree[j][k].Npath[h-1];
					}  
				}
		}
	}
	delete []start;
}
void displaynettree(vector <node> *nettree)
{
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size ();j++)
			if (nettree[i][j].used ==false)
				cout <<nettree[i][j].name <<"\t";
		cout <<endl;
	}
}

void updatenettree(vector <node> *nettree,int *nodenumber)
{   for(int tmp=0;tmp<nettree[ptn_len].size();tmp++){nettree[ptn_len][tmp].toleave=true;}
	nodenumber[ptn_len]=nettree[ptn_len].size ();
	for (int i=ptn_len-1;i>=0;i--)
	{   
		nodenumber[i]=0;
		for(int j=nettree[i].size ()-1;j>=0;j--)
		{
			bool flag=true;
		/*	nettree[i][j].toleave =!flag;
			if(nettree[i][j].children.size()!=0){
                for(int t=0;t<nettree[i][j].children.size();t++){
					if(nettree[i+1][t].toleave=true)
					{nettree[i][j].toleave =flag;break}
			}*/
			int size=nettree[i][j].children.size ();
			for (int k=0;k<size;k++)
			{
				int child=nettree[i][j].children[k];
				if (nettree[i+1][child].used ==false)
				{
					flag=false;					
					nodenumber[i]++;
					break;
				}
			}
			//���ڲ��ִܵ�Ҷ�ӽ��Ľ�㣬��ʶΪ����true��
			nettree[i][j].used =flag;
			for (int k1=0;k1<size;k1++)
			{
				int child=nettree[i][j].children[k1];
				if (nettree[i+1][child].toleave ==true)
				{
					flag=false;					
					break;
				}
			}
	    	nettree[i][j].toleave =!flag;
		}
	}
}

/*--------------------------�ҵ�һ�����ص����ֺ��������------------------------*/
#include<stack>
struct storenode
{
	int position;
	int level;
};
void updatenettree_length_pc(vector <node> *nettree,occurrence &occin,int T)
{	//���㷨�����ƣ�����ȫ�����������������з�ʽ����Ӱ��Ľڵ��������
	//���и��׺��ӵĶ�����
	for (int level=ptn_len;level>0;level--)
	{
		int position=occin.position [level];
		if(level<ptn_len)
		{
				int pos=occin.position[level+1];//�ϲ�ڵ�λ��
				int position_b=nettree[level+1][pos].parent[0];
				if(position_b<position) position=position_b;
		}		
		for (;position<nettree[level].size();position++)
		{
			//��ǰ�ҵ�һ��û��ʹ�õĽ�����
			if (nettree[level][position].used ==false&&nettree[level][position].UpdateN==false)
				break;
			//���׸���
			nettree[level][position].UpdateN=false;
			int len=nettree[level][position].parent .size ();
			//��ǰ���
			for (int i=0;i<=len-1;i++)
			{
				//ÿ������
				int parent=nettree[level][position].parent [i];
				nettree[level-1][parent].UpdateN=true;
				int cs=nettree[level-1][parent].children .size ();
				//�Ѿ��������߲��ɵִ�Ҷ��
				if (nettree[level-1][parent].used ==true)
					continue;
				if (cs==1&&nettree[level][position].used ==true)//��һ������
				{
					//��һ�����Ӿ�Ӧ�����������Ӳ�������
						nettree[level-1][parent].used =true;
						nettree[level-1][parent].toleave =false;
					//}
				}
				else
				{//���haizi
					for(int h=0;h<=T;h++)
				        nettree[level-1][parent].LNpath[h]=0;
					int b=0;
					for (int kk=0;kk<=cs-1;kk++)
					{
						int child=nettree[level-1][parent].children [kk];
						int name=nettree[level-1][parent].name ;
						if(nettree[level][child].used ==false)
						{
							if(S[name]==sub_ptn[level-1].start) 
							{
								for(int t=0;t<=T;t++) nettree[level-1][parent].LNpath[t]=nettree[level-1][parent].LNpath[t]+nettree[level][child].LNpath[t];
							}
					        else
							{
								nettree[level-1][parent].LNpath[0]=0;
								for(int t=1;t<=T;t++) nettree[level-1][parent].LNpath[t]=nettree[level-1][parent].LNpath[t]+nettree[level][child].LNpath[t-1];
							}
							b++;
						}	
					}
					if (b==0)
					{
						nettree[level-1][parent].used =true;
						nettree[level-1][parent].toleave =false;
					}
				}	
			}
		}
	}
}
int minvaleposition(int *nodenumber)
{
	int p=ptn_len;
	for (int i=p-1;i>=0;i--)
	{
		if (nodenumber[i]<=nodenumber[p])
			p=i;
	}
	return p;
}
void displayocc(occurrence &occ)
{
	//cout <<"An occurrence is:";
	cout <<"<";
	for (int i=0;i<ptn_len;i++)
		cout <<occ.position [i]<<",\t";
	cout <<occ.position [i];
	cout <<">"<<endl;
}
void displaychild(vector <node> *nettree)
{
	cout <<"--------child----------------\n";
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size ();j++)
		{
			//if (nettree[i][j].LPN >0)
			{
				//�Բ��ִܵ���Ҷ��Ľ�㲻����ʾ
				cout <<nettree[i][j].children .size ()  <<"\t";
			}
		}
		cout <<endl;
	}
}
//��ȡÿ���ڵ���С�����Ҷ�ӽڵ�
void minandmaxleaf(vector <node> *nettree,int d){
		//��ʼ��LNpath[]
	for(int i=0;i<ptn_len;i++){
		for(int j=0;j<nettree[i].size();j++){
		  for(int h=0;h<d+1;h++){
			nettree[i][j].LNpath[h]=0;}
		}
	}
	
    for(int n=0;n<nettree[ptn_len].size();n++){
		  
			 //������Ҷ�ڵ�����·����
		    int v=nettree[ptn_len][n].name;
			if(sub_ptn[ptn_len-1].end ==S[v])
			{        nettree[ptn_len][n].LNpath[0]=1;
			         for(int h=1;h<d+1;h++){nettree[ptn_len][n].LNpath[h]=0;}
			}
			else {   nettree[ptn_len][n].LNpath[0]=0;
			         nettree[ptn_len][n].LNpath[1]=1;
			         for(int h=2;h<d+1;h++){nettree[ptn_len][n].LNpath[h]=0;}
			}
	 }

	for(int m=ptn_len-1;m>=0;m--){		
	   	for(int t=0;t<nettree[m].size();t++){
		    	if(nettree[m][t].children.size()==0) continue;
			
			  
							  
							  //��ȷƥ�䵱ǰ�ڵ��·����=���ӽڵ��·��������
				 for(int c1=0;c1<nettree[m][t].children.size();c1++){
					 int v=nettree[m][t].name;
					 int chpos=nettree[m][t].children[c1];
					 if(nettree[m+1][chpos].toleave==true){
					 	 
						   	if(sub_ptn[m].start==S[v]){
							         for(int h=0;h<d+1;h++)
									   nettree[m][t].LNpath[h]=nettree[m][t].LNpath[h]+nettree[m+1][chpos].LNpath[h];
							}  
					       	else{
							        nettree[m][t].LNpath[0]=nettree[m][t].LNpath[0];
									for(int h=1;h<d+1;h++)
									nettree[m][t].LNpath[h]=nettree[m][t].LNpath[h]+nettree[m+1][chpos].LNpath[h-1];//cout<<nettree[m][t].name<<"eee";cout<<nettree[m][t].LNpath[h];}
							}
					 }
					    
				 }	
		}  
	}				
}


//version 1  ������Ҷ�Ӳ������
void nonover_cross(int d)
{
	vector <node> *nettree;
	nettree=new vector <node> [ptn_len+1];
	int *nodenumber;
	nodenumber=new int [ptn_len+1];
	createnettree(nettree,d);
//	displaynettree(nettree);
	updatenettree(nettree,nodenumber);
	minandmaxleaf(nettree,d);
//	cout <<"-------------------\n";
//	displaynettree(nettree);
//	displaychild(nettree);

	store.resize (0);
	for (int position=0;position<nettree[0].size();position++)
	{
		
		if (nettree[0][position].used==true||nettree[0][position].toleave==false)
		{
			//Ϊ�ٱ�ʾ���ִܵ����
			continue;
		}
		int root=nettree[0][position].name;

	
		if(sub_ptn[0].start==S[root])
	        	nettree[0][position].LeafApprox=0;
		else    nettree[0][position].LeafApprox=1;
        int wholeapprox=nettree[0][position].LeafApprox;
		//��������
		occurrence occ;
		occurrence occin;//�������е�λ�ã�
		occ.position .resize (ptn_len+1);
		occin.position .resize (ptn_len+1);
		occin.position [0]=position;
		occ.position [0]=nettree[0][position].name ;

		nettree[0][position].used =true;
		nettree[0][position].toleave =false;
		//��xia��������
		for (int j=1;j<=ptn_len;j++)
		{
			
			//���ݺ���������˫��
			int parent=occin.position [j-1];//fuqin�������е�λ��
			int cs=nettree[j-1][parent].children .size ();//��ǰ����˫����
			//if (ps<1)
			//	cout <<"imposible error\n";
			for (int t=0;t<=cs-1;t++)
			{
        		int hamflag;
				//int papprox;
				int child=nettree[j-1][parent].children[t];//����˫�׵�λ��
				int cchild=nettree[j][child].name;
		
				{
					if(sub_ptn[j-1].end==S[cchild])  hamflag=0;
					else hamflag=1;
					int maxh=d-wholeapprox;
					for(int c=0;c<=maxh;c++){
						if(nettree[j][child].LNpath[c]!=0)break;//�ж�����·����==0������һ�����ڵ�
					}
					if(c==maxh+1) continue;
				}
				if( (nettree[j][child].used ==false))
				{
					occin.position [j]=child;			//
					int value=nettree[j][child].name;
					
					occ.position [j]=value ;
					nettree[j][child].used=true;
					nettree[j][child].toleave =false;
					wholeapprox=wholeapprox+hamflag;
					break;
				}
			}
			
			if (t==cs)
			{
				//�����г���Լ����Ե�ʲ�������ȫ�������ɲ������ֵ�����
				//�ָ�����
				for (int kk=j-1;kk>0;kk--)
				{
					int pos=occin.position [kk];
					nettree[kk][pos].used=false;
					nettree[kk][pos].toleave =true;
				}
				break;
			}
		}		
		if (j==ptn_len+1)
		{
			int len=store.size ();
			store.resize (len+1);
			store[len]=occ;
			//updatenettree_length4(nettree,occin);
			updatenettree_length_pc(nettree,occin,d);
			//displaynettree(nettree);
		}
	}
}

void dealrange(char *p,int len)      
//put sub-pattern "a[1,3]b" into sub_ptn and sub_ptn.start=a��sub_ptn.end=b, sub_ptn.min=1��sub_ptn.max=3
{
	sub_ptn[ptn_len].start =p[0];
	sub_ptn[ptn_len].end =p[len];
	if (len==1)
	{
		sub_ptn[ptn_len].max =sub_ptn[ptn_len].min=0;
	}
	else
	{
		int value=0;
		int i;
		for ( i=2;p[i]!=',';i++)
			value=value*10+p[i]-48;
		sub_ptn[ptn_len].min=value;		
		value=0;
		for (int j=i+1;p[j]!=']';j++)
			value=value*10+p[j]-48;
		sub_ptn[ptn_len].max=value;
	}
	if (sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1>maxgap)
		maxgap=sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1;
	ptn_len++;
}

void convert_p_to_ruler(char *p)     //transform p into sub_ptn
{
	ptn_len = 0;
	char st,en;
	int l,r ;
	int len=strlen(p);
	st=p[0];
	en=p[len-1];
	if (isalpha(st) && isalpha(en))
	{
		l=0;
		for (int i=1;i<len;i++)
		{
			if (isalpha(p[i]))
			{
				r=i;
				dealrange(p+l,r-l);
				l=i;
			}
		}
	}
	else
	{
		cout<<"irregular pattern.\n";
		exit(-1);
	}
}
void disp_pattern()         //display the array sub_ptn
{
	for (int i=0;i<ptn_len;i++)
	{
		//printf("%c\t%d\t%d\t%c\n",sub_ptn[i].start ,sub_ptn[i].min , sub_ptn[i].max ,sub_ptn[i].end );
		cout<<sub_ptn[i].start<<"\t"<<sub_ptn[i].min<<"\t"
			<<sub_ptn[i].max<<"\t"<<sub_ptn[i].end<<endl;
	}
}
void Inputstr(char *fn,char *str)
{
	FILE* fp=fopen(fn,"r+");
	if (NULL==fp)
	{
		cout<<"Cannot find the file.\n";
		return;
	}
	fseek(fp,0,SEEK_END); 
	int len =ftell(fp);
	fseek(fp,0,0); 
	fscanf(fp, "%s",str);
}
void MakeUpper(char *S)
{
	for (int i=0;S[i];i++)
		if (S[i]>=97&& S[i]<='z')
			S[i]-=32;
}

void main()
{  	//ģʽ��
	char p1[200] = "A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T[0,3]A";
    char p2[200] = "G[1,5]T[0,6]A[2,7]G[3,9]T[2,5]A[4,9]G[1,8]T[2,9]A";
	char p3[200] = "G[1,9]T[1,9]A[1,9]G[1,9]T[1,9]A[1,9]G[1,9]T[1,9]A[1,9]G[1,9]T";
    char p4[200] = "G[1,5]T[0,6]A[2,7]G[3,9]T[2,5]A[4,9]G[1,8]T[2,9]A[1,9]G[1,9]T";
	char p5[200] = "A[0,10]A[0,10]T[0,10]C[0,10]G[0,10]G";
	char p6[200] = "A[0,5]T[0,7]C[0,9]G[0,11]G";
	char p7[200] = "A[0,5]T[0,7]C[0,6]G[0,8]T[0,7]C[0,9]G";
	char p8[200] = "A[5,6]C[4,7]G[3,8]T[2,8]A[1,7]C[0,9]G";
	char p9[200] = "C[0,5]T[0,5]G[0,5]A[0,5]A";



	//strcpy(S,"agagatgga");
	DWORD begintime[9] = {0};
	DWORD endtime[9] = {0};
	int count_each[9] = {0};
	int T=2;
	cout<<"�����뺺������T:";
	//cin>>T;
	int time_i = 0;
	for(time_i = 0; time_i < 9;time_i++)//9; time_i++)
	{
		int i_ts = 0;
		switch(time_i + 1) {
		case 1:
			convert_p_to_ruler(p1);
			goto F1;
			break;
		case 2:
			convert_p_to_ruler(p2);
			goto F1;
			break;
		case 3:
			convert_p_to_ruler(p3);
			goto F1;
			break;
		case 4:
			convert_p_to_ruler(p4);
			goto F1;
			break;
		case 5:
			convert_p_to_ruler(p5);
			goto F1;
			break;
		case 6:
			convert_p_to_ruler(p6);
			goto F1;
			break;
		case 7:
			convert_p_to_ruler(p7);
			goto F1;
			break;
		case 8:
			convert_p_to_ruler(p8);
			goto F1;
			break;
		case 9:
			convert_p_to_ruler(p9);
			goto F1;
			break;
		}	
F1:	//cout<<"The pattern can written as follows:\n";
//	disp_pattern();
	//char fsn[]="e:\\data\\S8.txt";

	//Inputstr(fsn,S);
	char fsn[]="S1.txt";

	Inputstr(fsn,S);
	MakeUpper(S);
	
    begintime[time_i]=GetTickCount();		
		nonover_cross(T);
	//for (int i=0;i<store.size();i++)
	//		displayocc(store[i]);
		count_each[time_i]=store.size();
    endtime[time_i]=GetTickCount();
	}
	for(time_i = 0; time_i < 9; time_i++){
	     cout << "ģʽ" << time_i+1 << "�Ľ����" << endl;
       	 cout <<"����"<<count_each[time_i]<<"������\t\t\t";
         cout <<"��ʱ"<<(endtime[time_i]-begintime[time_i])/1.0<<"ms. \n\n";
	}
}