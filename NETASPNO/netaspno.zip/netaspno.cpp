#include <iostream.h>
#include <string.h>
#include <afxwin.h>
#include <vector>
using namespace std;

#define N 400000
#define M 100
#define D 50
struct node
{
	int name;
	vector <int> parent;
	vector <int> children;
	bool used;			//used=true ��ʾɾ��
	//bool toroot;		//�ִ�����
	bool match;			//true ��ʾ��ȷ��false��ʾ����ȷ��
	int Npath[D];		//�ڵ�����·������
	//int LNpath[D];		//�ڵ�Ҷ��·������
	//int distance;
	int rootname;
};

char S[N];
struct sub_ptn_struct
{
	char start,end;		//
	int min,max;		//
};
struct occurrence
{
	vector <int > position;
};
vector <occurrence> store;
sub_ptn_struct sub_ptn[M];  //pattern p[i]
int ptn_len=0;  //the length of pattern-1=����-1=����±�ֵ
int seq_len=0;
int maxgap=-1;

/*---------------------------��ģʽ��ת��Ϊ��������------------------------------------------*/
void dealrange(char *p,int len)      
//put sub-pattern "a[1,3]b" into sub_ptn and sub_ptn.start=a��sub_ptn.end=b, sub_ptn.min=1��sub_ptn.max=3
{
	sub_ptn[ptn_len].start =p[0];
	sub_ptn[ptn_len].end =p[len];
	if (len==1)
	{
		sub_ptn[ptn_len].max =sub_ptn[ptn_len].min=0;
	}
	else
	{
		int value=0;
		int i;
		for ( i=2;p[i]!=',';i++)
			value=value*10+p[i]-48;
		sub_ptn[ptn_len].min=value;		
		value=0;
		for (int j=i+1;p[j]!=']';j++)
			value=value*10+p[j]-48;
		sub_ptn[ptn_len].max=value;
	}
	if (sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1>maxgap)
		maxgap=sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1;
	ptn_len++;//
}

void convert_p_to_ruler(char *p)     //transform p into sub_ptn
{
	ptn_len = 0;
	char st,en;
	int l,r ;
	int len=strlen(p);
	st=p[0];
	en=p[len-1];
	if (isalpha(st) && isalpha(en))
	{
		l=0;
		for (int i=1;i<len;i++)
		{
			if (isalpha(p[i]))
			{
				r=i;
				dealrange(p+l,r-l);
				l=i;
			}
		}
	}
	else
	{
		cout<<"irregular pattern.\n";
		exit(-1);
	}
}
void disp_pattern()         //display the array sub_ptn
{
	for (int i=0;i<ptn_len;i++)
	{

		cout<<sub_ptn[i].start<<"\t"<<sub_ptn[i].min<<"\t"
			<<sub_ptn[i].max<<"\t"<<sub_ptn[i].end<<endl;
	}
}
void Inputstr(char *fn,char *str)
{
	FILE* fp=fopen(fn,"r+");
	if (NULL==fp)
	{
		cout<<"Cannot find the file.\n";
		return;
	}
	fseek(fp,0,SEEK_END); 
	int len =ftell(fp);
	fseek(fp,0,0); 
	fscanf(fp, "%s",str);
}
void initial (node & anode,int i,int T)
{
	anode.name =i;
	anode.parent.resize (0);
	anode.children .resize (0);
	anode.used =false;//û��ʹ��Ϊ�٣����Ϊtrue����ʾ��ɾ�������ý��
	for(int h=0;h<T+1;h++)
		anode.Npath[h]=0;
}
void createnettree(vector <node> *nettree,int T)
{
	for (int i=0;i<ptn_len+1;i++)
		nettree[i].resize (0);//�������ʼ��
	int *start;
	start=new int[ptn_len+1];
	for (i=0;i<ptn_len+1;i++)
		start[i]=0;
	node enode;
	initial (enode,0,T);
	for (i=0;i<strlen(S);i++)
	{
		//��ÿ���ַ���һ���
		//�Խ����г�ʼ����
		node root=enode;
		root.name =i;

	    if(i<strlen(S)-ptn_len)
		{
			//ֱ�Ӵ洢�ý����Ϊ������
			int len=nettree[0].size ();
			nettree[0].resize (len+1);
			//root.toroot =true;
			nettree[0][len]=root;
			//thelast.position [0]=len;
			//thelast [0]=len;

            //���������ڵ�����·����
			if(sub_ptn[0].start ==S[i])
			{   
				nettree[0][len].match =true;
				nettree[0][len].Npath[0]=1;
				for(int h=1;h<T+1;h++)
				{
					nettree[0][len].Npath[h]=0;
				}
			}
			else 
			{
				nettree[0][len].match =false;
				nettree[0][len].Npath[0]=0;
				nettree[0][len].Npath[1]=1;
				for(int h=2;h<T+1;h++)
				{
					nettree[0][len].Npath[h]=0;
				}
			}   
		}
		for (int j=0;j<ptn_len;j++)
		{
			node anode;
			anode=enode;
			anode.name =i;
			/////////////////
			//if (sub_ptn[j].end==S[i])
			////////////////
			//��һ������˫��
			int prev_len=nettree[j].size ();
			if (prev_len==0)
			{
				//˵�����޽�㣬�����˳�
				break;
			}
			//�������  ������
			for (int k=start[j];k<prev_len;k++)
			{
				int name=nettree[j][k].name;
				if (i-nettree[j][k].name -1>sub_ptn[j].max )
				{
					//��������Ͻ죬�α����
					start[j]++;
				}
			}
			//�жϼ�϶Լ��
			if (i-nettree[j][prev_len-1].name -1>sub_ptn[j].max)
			{
				//����������϶Լ��
				continue;
			}
			if (i-nettree[j][start[j]].name -1<sub_ptn[j].min)
			{
				continue;
			}
			
			/////////////////
			/*int len=nettree[j+1].size ();
			nettree[j+1].resize (len+1);
			anode.toroot =true;
			nettree[j+1][len]=anode;*/
			/////////////////
			bool createnode=false;
			for (k=start[j];k<prev_len;k++)
			{
				//�ж��Ƿ������϶Լ��
				int name=nettree[j][k].name;
				if (i-nettree[j][k].name -1>sub_ptn[j].max )
				{
					//��������Ͻ죬�α����
					start[j]++;
					continue;
				}
				if (i-nettree[j][k].name -1<sub_ptn[j].min )
				{
					//��������½磬�˳�
					break;
				}
				//�����϶Լ������ʼ�ж��Ƿ�������ƾ�����ֵ
				if(sub_ptn[j].end==S[i])
				{
					//nettree[j+1][len].match =true;
					anode.match =true;
					createnode=true;
					int nc=nettree[j][k].children .size ();
					nettree[j][k].children.resize (nc+1);
					int len=nettree[j+1].size ();
					nettree[j][k].children [nc]=len;//�洢λ��
					
					/*int np=nettree[j+1][len].parent .size ();
					nettree[j+1][len].parent.resize (np+1);
					nettree[j+1][len].parent [np]=k;*/
					int np=anode.parent .size ();
					anode.parent.resize (np+1);
					anode.parent [np]=k;
					//��ʼ����������Ҷ��·������ Npath[h]  
						
					for(int h=0;h<T+1;h++)
							//nettree[j+1][len].Npath[h] += nettree[j][k].Npath[h];      
						anode.Npath[h] += nettree[j][k].Npath[h];            
				}
				else
				{
					//�Ǿ�ȷƥ��
					//nettree[j+1][len].match =false;
					anode.match =false;
					bool notAllZero = false;					
					//nettree[j+1][len].PNpath[0]=0;
					for(int h=1;h<T+1;h++)
					{
						if (nettree[j][k].Npath[h-1]!=0)
						{
							notAllZero=true;
							createnode=true;
							break;
							//	nettree[j+1][len].PNpath[h]=nettree[j][k].Npath[h-1];
						}
					}
					if (!notAllZero)
						continue;
					
					//�ڼ�϶Լ��֮�䣬������ƾ���Լ��
					//�������ӹ�ϵ
					int nc=nettree[j][k].children .size ();
					nettree[j][k].children.resize (nc+1);
					int len=nettree[j+1].size ();
					nettree[j][k].children [nc]=len;//�洢λ��
					/*int np=nettree[j+1][len].parent .size ();
					nettree[j+1][len].parent.resize (np+1);
					nettree[j+1][len].parent [np]=k;*/
					int np=anode.parent .size ();
					anode.parent.resize (np+1);
					anode.parent [np]=k;					
					//��ʼ����������Ҷ��·������ Npath[h]  
						anode.Npath[0]=anode.Npath[0];
						for(h=1;h<T+1;h++)
							anode.Npath[h] += nettree[j][k].Npath[h-1];
				}
			}
			//if (i==7&&j==ptn_len-1)
			//	i=7;
			if (createnode==true)
			{
				int jlen=nettree[j+1].size ();
				nettree[j+1].resize (jlen+1);
				//anode.toroot =true;
				nettree[j+1][jlen]=anode;				
				//thelast.position [j+1]=len;
				//thelast [j+1]=len;
			}
		}
	}
	delete []start;
}
void displaynettree(vector <node> *nettree, int *thelast)
{
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		int size=thelast[i];
		if (size<0)
			size=nettree[i].size ()-1;
		for (int j=0;j<=size;j++)
		//for (int j=0;j<=5;j++)
		//for (int j=0;j<nettree[i].size ();j++)
			if (nettree[i][j].used ==false)
			{
				//cout <<"["<<nettree[i][j].Npath [0]<<"]";
				//cout <<"["<<nettree[i][j].LNpath [0]<<"]";
				cout <<"["<<nettree[i][j].Npath [0]<<nettree[i][j].Npath [1]<<"]";
				//cout <<"["<<nettree[i][j].LNpath [0]<<nettree[i][j].LNpath [1]<<"]";
				cout <<j<<"$"<<nettree[i][j].match <<" ";
				cout <<nettree[i][j].name+1<<"\t";
			}
		cout <<endl;
	}
	cout <<endl<<endl;
}
void displayocc(occurrence &occ)
{
	//cout <<"An occurrence is:";
	cout <<"<";
	for (int i=0;i<ptn_len;i++)
	{
		cout <<occ.position [i]<<",\t";
	}
	cout <<occ.position [i];
	cout <<">"<<endl;
}


/*---------�����������������(�����ִܵ�Ҷ�ӽ��Ľ�㣬��ʶΪ����)--------*/
/*void updatenettree(vector <node> *nettree,int *nodenumber, int  *thelast,int T)
{
	//��ʼ��LNpath[]
	for(int i=0;i<ptn_len+1;i++)
	{
		for(int j=0;j<nettree[i].size();j++)
		{
			if (nettree[i][j].used ==true)
				continue;
			for(int h=0;h<T+1;h++)
			{
				nettree[i][j].LNpath[h]=0;
			}
		}
	}	
	//������Ҷ�ڵ�����·����
    for(int n=0;n<nettree[ptn_len].size();n++)
	{

		int v=nettree[ptn_len][n].name;
		if (nettree[ptn_len][n].used ==true)
				continue;

		//thelast [ptn_len]=n;

		//cout <<v<<"\t";
		if(sub_ptn[ptn_len-1].end ==S[v])
		{
			nettree[ptn_len][n].LNpath[0]=1;
		}
		else 
		{   
			nettree[ptn_len][n].LNpath[1]=1;
		}
	}
	//������������м���
	thelast [ptn_len]=nodenumber[ptn_len]=nettree[ptn_len].size ()-1;
	for ( i=ptn_len-1;i>=0;i--)
	{
		if (i==0)
			i=0;
		nodenumber[i]=0;
		bool flaglast=true;
		for(int j=nettree[i].size ()-1;j>=0;j--)
		{
			if (nettree[i][j].used== true)
				continue;
			bool flag=true;
			int size=nettree[i][j].children.size ();

			if (size<=0)
			{
				nettree[i][j].used=true;
			}
			else
			{
				int name=nettree[i][j].name ;
				for (int k=0;k<size;k++)
				{
					int child=nettree[i][j].children[k];
					//int childname=nettree[i+1][child].name ;
					//node childnode=nettree[i+1][child];
					if (nettree[i+1][child].used ==false)
					{
						flag=false;					
						if(nettree[i][j].match ==true)//(sub_ptn[i].start==S[name])
						{
							for(int h=0;h<T+1;h++)
								nettree[i][j].LNpath[h] +=nettree[i+1][child].LNpath[h];
						}  
						else
						{
							//nettree[i][j].LNpath[0]=nettree[i][j].LNpath[0];
							for(int h=1;h<T+1;h++)
								nettree[i][j].LNpath[h] += nettree[i+1][child].LNpath[h-1];//cout<<nettree[m][t].name<<"eee";cout<<nettree[m][t].LNpath[h];}
						}				
						//break;
					}
				}				
				//���ڲ��ִܵ�Ҷ�ӽ��Ľ�㣬��ʶΪ���ã�
				nettree[i][j].used =flag;
				bool lnp=true;
				for (int h=0;h<T+1;h++)
					if (nettree[i][j].LNpath[h]>0)
					{
						lnp=false;
						break;
					}
				nettree[i][j].used =lnp;
				if (nettree[i][j].used==false)
				{
					if (flaglast==true)
					{
						flaglast=false;
						thelast [i]=j;
					}
					nodenumber[i]++;
				}
			}
		}		
	}
}*/
occurrence getocc(int *occin, vector <node> *nettree, int T)
{
	occurrence occ;
	occ.position .resize (ptn_len+1);
	int distance=0;
	for (int i=0;i<=ptn_len;i++)
	{
		int position=occin[i];
		int name=nettree[i][position].name;
		occ.position [i]=name ;
		if (nettree[i][position].match ==false)
			distance++;
	}
	/*if (distance>T)
		cout <<"error";
	else
		cout <<"ok";*/
	return occ;
}
int findanocc(int rootposition,vector <node> *nettree, int *thelast, int T)
{
	node *root, *current,*child;
	root=& nettree[0][rootposition];
	root->rootname =root->name ;
	int rootname=root->name;
	int start,end,childposition;
	start=end=rootposition;
	for (int ii=0;ii<=T;ii++)
	{
		root->Npath[ii]=0; 
	}
	if (root->match ==false)
	{
		root->Npath[1]=1;
	}
	else
	{
		root->Npath[0]=1;
	}
	int startc,endc;
	for (int i=0;i<ptn_len;i++)
	{
		bool thefirst=true;
		for (int j=start;j<=end;j++)
		{
			current=& nettree[i][j];
					if (rootname==493&&i==1)
						rootname=493;
			if (current->used ==true)
				continue;
			//��ǰ������ڲ��ܱ�ʹ��
			if (current->rootname  !=rootname)
				continue;
			int number=0;
			for (ii=0;ii<=T;ii++)
				number+=current->Npath [ii];
			if (number==0)
				continue;
			//current.rootname =rootname;
			//currentdistance=current->distance ;
			int childnumber=current->children .size ();
			for (int k=0;k<childnumber;k++)
			{
				childposition=current->children [k];
				child= & nettree[i+1][childposition];
				if (child->used ==true)
				{
					continue;
				}
				bool notzero=false;
				if (child->rootname != rootname)
				{
					//������һ�η��ʸý��
					child->rootname =rootname;
					if (child->match ==false)
					{
						//����Ϊ1
						child->Npath [0]=0;
						for (ii=1;ii<=T;ii++)
						{
							child->Npath [ii]=current->Npath [ii-1];
							if (child->Npath [ii]>0)
								notzero=true;
						}
					}
					else
					{
						//����Ϊ0
						notzero=true;
						for (ii=0;ii<=T;ii++)
							child->Npath [ii]=current->Npath [ii];
					}
				}
				else
				{
					//���ǵ�һ���ʸý��
					if (child->match ==false)
					{
						//����Ϊ1
						for (ii=1;ii<=T;ii++)
						{
							child->Npath [ii]+=current->Npath [ii-1];
							if (child->Npath [ii]>0)
								notzero=true;
						}
					}
					else
					{
						//����Ϊ0
						notzero=true;
						for (ii=0;ii<=T;ii++)
							child->Npath [ii]+=current->Npath [ii];
					}
				}
				if (notzero==true)
				{
					if (thefirst==true)
					{
						thefirst=false;
						startc=childposition;
						endc=childposition;
					}
					if (startc>childposition)
						startc=childposition;
					if (endc<childposition)
						endc=childposition;
					/*if (rootname==525)
					{
						cout<<i<<":"<<" "<<current->name <<"=>" <<child->name <<" "<<current->Npath[0] <<","
							<<current->Npath[1]<<"[]"<<child->Npath[0] <<","<<child->Npath[1]<<" "<<child->match <<"\n";
					}*/
				}
			}
		}
		if (thefirst==true)
		{
			//˵���޺��ӽ�㣬���ִܵ�Ҷ�ӣ�
			return -1;
		}
		else
		{	//������һ���㿪ʼ�����
			start=startc;
			end=endc;
		}
	}
	return end;
	//return childposition;
}
void deleteocc(int *occin,vector <node> *nettree)
{
	for (int i=0;i<=ptn_len;i++)
	{
		nettree[i][occin[i]].used =true;
	}
}
int doublecheck(int *occin,vector <node> *nettree,int T)
{
	int distance=0;
	for (int i=0;i<=ptn_len;i++)
	{
		node *anode=&nettree[i][occin[i]];
		if (anode->match ==false)
			distance++;
	}
	return distance;
}
void rightmostocc(int *occin,vector <node> *nettree,int T)
{
	int T1=T;
	int rootname=nettree[0][occin[0]].name;
	node *current=& nettree[ptn_len][occin[ptn_len]];
	//int distance=0;
	//if (nettree[0][occin[0]].match ==false)
	//	T--;
	//����������ѡ���ټ���
	for (int i=ptn_len;i>0;i--)
	{
		if (current->match ==false)
			T-=1;
		int parentnumber=current->parent .size ();
		node *parent;
		for (int j=parentnumber-1;j>=0;j--)
		{
			int parentposition=current->parent [j];
			parent=&nettree[i-1][parentposition];
			if (parent->used ==true)
				continue;
			//����ʹ��˫�׽�㣻
			if (parent->rootname ==rootname)
			{
				//if (rootname==43)
				//	cout<<i<<":"<<current->name <<"->"<<parent->name <<parent->match <<","<<parent->Npath [0]<<"."<<parent->Npath [1]
				//			<<" "<<T<<"\n";
				//��ȷƥ��ֱ��ѡ��
				int d=1;
				if (parent->match ==true)
				{
					d=0;

				}
				//����ƥ����Ҫ����Ӧ���������ݣ�
				for (int ii=d;ii<=T;ii++)
					if (parent->Npath [ii]>0)
						break;
				//����û��break;
				if (ii==T+1)
					continue;
				occin[i-1]=parentposition;
				current=parent;			
				break;
			}
		}
		//if (j<0)
		//{
		//	j=-1;
		//	cout <<"-------------------rererereeree"<<parent->name <<","<<current->name ;
		//}		
	}
	//int result=1;
	//result=doublecheck(occin,nettree,T1);
	//if (result>T1)
	//{
	//	cout <<"eeeeeeeeeeeerrrrrrrrrrrrrroooooo\n";
		//distance=0;
	//}
}
void appro_nonoverlevel(int T)
{
	vector <node> *nettree;
	nettree=new vector <node> [ptn_len+1];
	int *nodenumber;
	nodenumber=new int [ptn_len+1];

	//occurrence thelast;
	//thelast.position .resize (ptn_len+1);
	int *thelast;
	thelast=new int [ptn_len+1];
	createnettree(nettree,T);
	cout <<"\n------------\n";
	//displaynettree(nettree,thelast);
	//cout <<"\n------------\n";

	//thelast��ʾÿ�������Ч����λ�ã�
	//updatenettree(nettree,nodenumber,thelast,T);	
	//displaynettree(nettree,thelast);
	int *occin;//�������е�λ�ã�
	occin=new int [ptn_len+1];

	for (int i=nettree[0].size ()-1;i>=0;i--)
	//for (int i=thelast[0];i>=0;i--)
	{
		node root=nettree[0][i];
		if (root.used ==true)
			continue;
		occin[0]=i;
//		if (root.name ==43)
		//{
//			cout <<"----------------\n";
			//displaynettree(nettree,thelast);
		//}
		//result��ʾҶ�Ӳ���ĩβ��Ҷ��
		int result=findanocc(i,nettree,thelast, T);
		if (result>=0)
		{
			//�����ִ洢����
			occin[ptn_len]=result;
			rightmostocc(occin,nettree,T);			
			int len=store.size ();
			store.resize (len+1);
			//doublecheck(store[len],nettree,T);
			store[len]=getocc(occin,nettree,T);
			//displayocc(store[len]);
			deleteocc(occin,nettree); 
			//cout <<"------------------------\n";
			//displaynettree(nettree,thelast);
		}
	}
}

void MakeUpper(char *S)
{
	for (int i=0;S[i];i++)
		if (S[i]>=97&& S[i]<='z')
			S[i]-=32;
}

void nonoverlapping(int time_i,int T, DWORD *begintime,  DWORD *endtime, int *count_each)
{
    begintime[time_i]=GetTickCount();		
	appro_nonoverlevel(T);
	//for (int i=0;i<store.size();i++)
	//{
	//	cout <<i<<":";
	//	displayocc(store[i]);
	//}
	count_each[time_i]=store.size();
    endtime[time_i]=GetTickCount();

}
void main()
{  	//ģʽ��
	//char p1[200] = "A[0,2]C";
	//char p1[200] = "A[0,1]G[0,1]A[0,2]A";
	//char p1[200] = "A[0,1]B[0,2]C";
	//char p1[200] = "B[0,2]C";
	//char p1[200] = "A[0,1]B[0,2]C[0,1]D";
	char p1[200] = "A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T[0,3]A";
	//char p1[200] = "A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T[0,3]A[0,3]T";
	//char p1[200] = "A[0,3]T[0,3]A[0,3]T[0,3]A";

    char p2[200] = "G[1,5]T[0,6]A[2,7]G[3,9]T[2,5]A[4,9]G[1,8]T[2,9]A";
	char p3[200] = "G[1,9]T[1,9]A[1,9]G[1,9]T[1,9]A[1,9]G[1,9]T[1,9]A[1,9]G[1,9]T";
    char p4[200] = "G[1,5]T[0,6]A[2,7]G[3,9]T[2,5]A[4,9]G[1,8]T[2,9]A[1,9]G[1,9]T";
	char p5[200] = "A[0,10]A[0,10]T[0,10]C[0,10]G[0,10]G";
	char p6[200] = "A[0,5]T[0,7]C[0,9]G[0,11]G";
	char p7[200] = "A[0,5]T[0,7]C[0,6]G[0,8]T[0,7]C[0,9]G";
	char p8[200] = "A[5,6]C[4,7]G[3,8]T[2,8]A[1,7]C[0,9]G";
	char p9[200] = "C[0,5]T[0,5]G[0,5]A[0,5]A";
	
	
	//strcpy(S,"CAAC");
	//strcpy(S,"aacbec");
	//strcpy(S,"cbec");
	//strcpy(S,"aacbecdd");
	//strcpy(S,"aggtagagaaggtagagaaggtagaga");
	//strcpy(S,"aggtagaga");
	//strcpy(S,"aggtagagaaggtagagaaggtagagaaggtagaga");
	char fsn[]="S2.txt";
	Inputstr(fsn,S);
	MakeUpper(S);

	//cout<<S;

	DWORD begintime[9] = {0};
	DWORD endtime[9] = {0};
	int count_each[9] = {0};
	int T;
	cout<<"�����뺺������T:";
	//cin>>T;
	T=1;
	int time_i = 0;
	for(time_i =0; time_i <9; time_i++)
	{
		int i_ts = 0;
		switch(time_i + 1) 
		{
		case 1:
			convert_p_to_ruler(p1);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 2:
			convert_p_to_ruler(p2);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 3:
			convert_p_to_ruler(p3);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 4:
			convert_p_to_ruler(p4);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 5:
			convert_p_to_ruler(p5);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 6:
			convert_p_to_ruler(p6);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 7:
			convert_p_to_ruler(p7);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 8:
			convert_p_to_ruler(p8);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		case 9:
			convert_p_to_ruler(p9);
			nonoverlapping (time_i,T, begintime, endtime, count_each);
			break;
		}
	}
	for(time_i = 0; time_i <9; time_i++)
	{
	     cout << "ģʽ" << time_i+1 << "�Ľ����" << endl;
		 if (time_i==0)
			 cout <<"����"<<count_each[time_i]<<"������\t\t";
		 else
			cout <<"����"<<count_each[time_i]-count_each[time_i-1]<<"������\t\t";
         cout <<"��ʱ"<<(endtime[time_i]-begintime[time_i])/1.0<<"ms. \n\n";
	}
}