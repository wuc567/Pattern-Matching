#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <fstream>
using namespace std;
#define K 600    //The sequence number of sequence database
#define M 100   //The length of pattern
#define N 20000  //The length of sequence
struct node         //nettree node
{
	int name;     //The corresponding position of node in sequence
	int min_leave,max_leave;   //The position of maxinum and mininum leave nodes
	vector <int> parent;     //The position set of parents
	vector <int> children;  //The position set of children
	bool used;      //true is has used, false is has not used
	bool toleave;  //true is can reach leaves, false is not
};
struct seqdb                 
{
	int id;                  // sequence id
	char S[N];              // sequence
} sDB[K];             
struct occurrence   //occurrence
{
	vector <int > position;
};
struct sub_ptn_struct   //a[0,3]c => start[min,max]end
{
	char start,end;		
	int min,max;
};
vector <occurrence> store;
sub_ptn_struct sub_ptn[M];  //pattern p[i]
int ptn_len=0;  //the length of pattern
int seq_len=0;
int maxgap=-1; //gap constraint
char S[N];  //sequence

void dealrange(char *p,int len)      
//put sub-pattern "a[1,3]b" into sub_ptn and sub_ptn.start=a��sub_ptn.end=b, sub_ptn.min=1��sub_ptn.max=3
{
	sub_ptn[ptn_len].start =p[0];
	sub_ptn[ptn_len].end =p[len];
	if (len==1)
	{
		sub_ptn[ptn_len].max =sub_ptn[ptn_len].min=0;
	}
	else
	{
		int value=0;
		int i;
		int flag=0;
		for (i=2;p[i]!=',';i++)
	    	if(p[i]=='-')
				flag=1;
		    else
		        value=value*10+p[i]-48;
	 	    if(flag==1)
		        sub_ptn[ptn_len].min=-value;
		    else
			    sub_ptn[ptn_len].min=value;
		    flag=0;
		    value=0;
		    for (int j=i+1;p[j]!=']';j++)
			     if(p[j]=='-')
			          flag=1;
			     else
				     value=value*10+p[j]-48;
			     if(flag==1)
				     sub_ptn[ptn_len].max=-value;
			     else
				     sub_ptn[ptn_len].max=value;
	}
	if (sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1>maxgap)
		maxgap=sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1;
	ptn_len++;
}


//find the first position of cand in the level of freArr by binary search
void convert_p_to_ruler(char *p)     //transform p into sub_ptn
{
	char st,en;
	int l,r ;
	int len=strlen(p);
	st=p[0];
	en=p[len-1];
	if (isalpha(st) && isalpha(en))
	{
		l=0;
		for (int i=1;i<len;i++)
		{
			if (isalpha(p[i]))
			{
				r=i;
				dealrange(p+l,r-l);
				l=i;
			}
		}
	}
	else
	{
		cout<<"irregular pattern.\n";
		exit(-1);
	}
}
void disp_pattern()         //display the array sub_ptn
{
	for (int i=0;i<ptn_len;i++)
	{
		//printf("%c\t%d\t%d\t%c\n",sub_ptn[i].start ,sub_ptn[i].min , sub_ptn[i].max ,sub_ptn[i].end );
		cout<<sub_ptn[i].start<<"\t"<<sub_ptn[i].min<<"\t"
			<<sub_ptn[i].max<<"\t"<<sub_ptn[i].end<<endl;
	}
}

void create_nettree(vector <node> *nettree)
{
	int *start;
	start=new int[ptn_len+1];
	int i;
	for (i=0;i<ptn_len+1;i++)
		start[i]=0;
	for(i=0;i<ptn_len+1;i++)
		nettree[i].resize(0);
	for(int j=0;j<ptn_len+1;j++)
	{
		char cchar = j == ptn_len ? sub_ptn[j-1].end : sub_ptn[j].start;
		if(j==0)
		{
			for( i=0;i<strlen(S);i++)
		    { 
				node anode;
				anode.name =i;
				anode.parent.resize (0);
				anode.children .resize (0);
				anode.max_leave=anode.name;
				anode.min_leave=anode.name;
				anode.used =false;
				if(cchar==S[i])
				{ 
					int len=nettree[0].size();
					nettree[0].resize(len+1);
					anode.toleave =true;
					nettree[0][len]=anode;
				}
			}
		}
		else
		{
			int p=nettree[j-1].size();
			int n=nettree[j-1][0].name;
			int m=nettree[j-1][p-1].name;
			
			if(sub_ptn[j-1].min>=0)
			{
				for(i=n+sub_ptn[j-1].min+1;i<=m+sub_ptn[j-1].max+1;i++)
				{
					node anode;
					anode.name =i;
					anode.parent.resize (0);
					anode.children .resize (0);
				    anode.max_leave=anode.name;
				    anode.min_leave=anode.name;
				    anode.used =false;
					if(cchar==S[i])
					{
						int len=nettree[j].size();
						nettree[j].resize(len+1);
						anode.toleave =true;
						nettree[j][len]=anode;
						for(int k=start[j-1];k<p;k++)
						{
							int n=nettree[j-1][k].name;
							if(i<n+sub_ptn[j-1].min+1)
								break;
							else if(i>n+sub_ptn[j-1].max+1)
								continue;
							else if(i>=n+sub_ptn[j-1].min+1&&i<=n+sub_ptn[j-1].max+1)
							{
								if(n!=i)
								{
									int nc=nettree[j-1][k].children.size();
								    nettree[j-1][k].children.resize(nc+1);
								    nettree[j-1][k].children[nc] =len;
								   int np=nettree[j][len].parent.size();
								   nettree[j][len].parent.resize(np+1);
								   nettree[j][len].parent[np]=k;
								}
								else
									continue;
							}
						}	
						
					}
				}
			}	
			else if(sub_ptn[j-1].max<0)
			{
				for(i=n+sub_ptn[j-1].min;i<=m+sub_ptn[j-1].max;i++)
				{
					node anode;
					anode.name =i;
					anode.parent.resize (0);
					anode.children .resize (0);
					anode.max_leave=anode.name;
				    anode.min_leave=anode.name;
					anode.used =false;
					if(cchar==S[i])
					{
						int len=nettree[j].size();
						nettree[j].resize(len+1);
						anode.toleave =true;
						nettree[j][len]=anode;
						for(int k=start[j-1];k<p;k++)
						{
							int n=nettree[j-1][k].name;
							if(i<n+sub_ptn[j-1].min)
								break;
							else if(i>n+sub_ptn[j-1].max)
								continue;
							else if(i>=n+sub_ptn[j-1].min&&i<=n+sub_ptn[j-1].max)
							{
								if(n!=i)
								{
									int nc=nettree[j-1][k].children.size();
								    nettree[j-1][k].children.resize(nc+1);
								    nettree[j-1][k].children[nc] =len;
								   int np=nettree[j][len].parent.size();
								   nettree[j][len].parent.resize(np+1);
								   nettree[j][len].parent[np]=k;
								}
								else
									continue;
							}
						}	
					}
				}
			}
			else if(sub_ptn[j-1].min<0&&sub_ptn[j-1].max>=0)
			{
				for(i=n+sub_ptn[j-1].min;i<=m+sub_ptn[j-1].max+1;i++)
				{
					node anode;
					anode.name =i;
					anode.parent.resize (0);
					anode.children .resize (0);
					anode.max_leave=anode.name;
				    anode.min_leave=anode.name;
					anode.used =false;
					if(cchar==S[i])
					{
						int len=nettree[j].size();
						nettree[j].resize(len+1);
						anode.toleave =true;
						nettree[j][len]=anode;
						for(int k=start[j-1];k<p;k++)
						{
							int n=nettree[j-1][k].name;
							if(i<n+sub_ptn[j-1].min)
								break;
							else if(i>n+sub_ptn[j-1].max+1)
								continue;
							else if(i>=n+sub_ptn[j-1].min&&i<=n+sub_ptn[j-1].max+1)
							{
								if(n!=i)
								{
									int nc=nettree[j-1][k].children.size();
								    nettree[j-1][k].children.resize(nc+1);
								    nettree[j-1][k].children[nc] =len;
								   int np=nettree[j][len].parent.size();
								   nettree[j][len].parent.resize(np+1);
								   nettree[j][len].parent[np]=k;
								}
								else
									continue;
							}
						}	
					}
				}
			}
		
		}
		
   	}

}





void displaynettree(vector <node> *nettree)
{
    cout<<"The nettree is as follow:\n";
	cout<<"--------------------------------------------------------------------------\n";
	for (int i=0;i<ptn_len+1;i++)
	{
		cout << i <<" level:  ";
		for (int j=0;j<nettree[i].size ();j++)
			if (nettree[i][j].used ==false)
			{	cout <<nettree[i][j].name <<"\t";
		        cout <<nettree[i][j].name <<".parent.size()=" << nettree[i][j].parent.size() <<"\t";
			    cout <<nettree[i][j].name <<".min_leave=" << nettree[i][j].min_leave <<"\t";
                cout <<nettree[i][j].name <<".max_leave=" << nettree[i][j].max_leave <<"\t";
			   // cout <<nettree[i][j].name <<".toleave="<< nettree[i][j].toleave<<"\t";
				cout <<nettree[i][j].name <<".used="<< nettree[i][j].used <<endl;
			}
				cout <<"\n";
		        cout <<endl;
	}
}


void update_nettree(vector <node> *nettree)        
{
	for(int i = ptn_len-1; i >= 0; i--)
	{
		
		for(int j =nettree[i].size()-1; j>=0 ; j--)
		{
			bool flag = true;
			int size = nettree[i][j].children.size();
			for(int k=0; k<size; k++)
			{
				int child=nettree[i][j].children[k];
				if(nettree[i+1][child].toleave == true)
				{
					nettree[i][j].max_leave = nettree[i+1][child].max_leave;
					
				}					
				if (nettree[i+1][child].used ==false)
				{
					 flag=false;
				
				}
			}
            for(int h=0; h<size; h++)
			{
				int child=nettree[i][j].children[h];
				if(nettree[i+1][child].toleave == true)
				{
					nettree[i][j].min_leave = nettree[i+1][child].min_leave;
					break;
					
				}
			}
			nettree[i][j].used =flag;
			if(flag==true)
			{
				nettree[i][j].max_leave=nettree[i][j].name;
				nettree[i][j].min_leave=nettree[i][j].name;
				nettree[i][j].toleave = false;
			}

		}
	}
}


void update_nettree_pc(vector <node> *nettree,occurrence &occin)
{
	//The advantage of the algorithm is do not have to traverse the entire nettree and just set the affected node as line way
	for (int level=ptn_len;level>0;level--)
	{
		int position=occin.position [level];
		int num = nettree[level].size();
		for (;position<num;position++)
		{
			//find a node that is not used backwards and break
			if (nettree[level][position].used ==false)
				break;
			//the number of parents
			int len=nettree[level][position].parent .size ();
			//int name=nettree[level][position].name ;
			for (int i=0;i<len;i++)
			{
				int parent=nettree[level][position].parent [i];
				int cs=nettree[level-1][parent].children .size ();
				//parent node have been used or cannot reach leaf node
				if (nettree[level-1][parent].used ==true)
					continue;
				if (cs==1)   //one child
				{
					nettree[level-1][parent].used =true;
					nettree[level-1][parent].toleave =false;
				}
				else
				{
					for (int kk=0;kk<cs;kk++)
					{
						int child=nettree[level-1][parent].children [kk];
						if(nettree[level][child].used ==false)
							break;
					}
					if (kk==cs)
					{
						nettree[level-1][parent].used =true;
						nettree[level-1][parent].toleave =false;
					}
				}	
			}
		}
	}	
}
 
void displayocc(occurrence &occ)
{
	//cout <<"An occurrence is:";
	cout <<"<";
	for (int i=0;i<ptn_len;i++)
		cout <<occ.position [i]<<",\t";
	cout <<occ.position [i];
	cout <<">"<<endl;
}
void nonoverlength()
{
	
	vector <node> *nettree;
	nettree=new vector <node> [ptn_len+1];
	int *nodenumber;
	nodenumber=new int [ptn_len+1];
	create_nettree(nettree);
	//displaynettree(nettree);
//	update_nettree_root(nettree);
	update_nettree(nettree);
//	displaynettree(nettree);
//	cout <<"-------------------\n";

	store.resize (0);
	for (int position=0;position<nettree[0].size ();position++)
	{
		
/*		if (nettree[0][position].toleave ==false)
		{
			continue;
		} */
		int root=nettree[0][position].name;

		//��������
		occurrence occ;
		occurrence occin;//�������е�λ�ã�
 		occ.position.resize (ptn_len+1);
		occin.position.resize (ptn_len+1);
		occin.position[0]=position;
		occ.position[0]=nettree[0][position].name ;
		nettree[0][position].used=true;
	//	nettree[0][position].toleave=false;
		for (int j=1;j<ptn_len+1;j++)
		{
		    int parent=occin.position [j-1];    //The position of the parent in nettree
			int cs=nettree[j-1][parent].children.size ();   //The number of children of the current node
 			for (int t=0;t<cs;t++)
			{
			    int child=nettree[j-1][parent].children[t];    //The position of the most left child
				int nodename=nettree[j][child].name;
				if(nettree[j][child].used == true)
				{
				      continue;
				}
				if(nettree[j][child].used ==false)
				{
	
                        occin.position[j]=child;			
						nettree[j][child].used=true;
						occ.position [j]=nodename;
					//	nettree[j][child].toleave =false;
						break;
				}
		
					
				
			}   
			if (t==cs)
			{
				//�����г���Լ����Ե�ʲ�������ȫ�������ɲ������ֵ�����
				//�ָ�����
				for (int kk=0;kk<j;kk++)
				{
					int pos=occin.position [kk];
					nettree[kk][pos].used=false;
				//	nettree[kk][pos].toroot =true;
				}
				break;
			}
			
			
		}
		if (j==ptn_len+1)
		{

			int len=store.size ();
			store.resize (len+1);
			store[len]=occ;
            update_nettree_pc(nettree,occin);
		}
	}
	delete []nettree;
}

void Inputstr(char *fn,char *str)
{
	FILE* fp=fopen(fn,"r+");
	if (NULL==fp)
	{
		cout<<"Cannot find the file.\n";
		return;
	}
	fseek(fp,0,SEEK_END); 
	int len =ftell(fp);
	fseek(fp,0,0); 
	fscanf(fp, "%s",str);
}

//compute support

void main()
{
//   char p[M]="t[-2,2]c[-2,2]a";
//	char p[M]="a[-5,6]c[-4,7]g[-3,8]t";
//    char p[M]="a[-2,4]b[-1,1]c[-1,2]d";
//char p[M]="a[0,1]g[0,1]a[0,3]b";
	
      //strcpy(S,"adbcadbcbbdaddc");
	//atggactccaacaccat////gtcaagctttcaggtagac
//	char p[M]="c[-1,2]a[-2,3]c[-3,4]g";
//	char p[M]="g[1,2]t[0,3]c[-3,4]g";
//	char p[M]="t[-2,2]c[-2,2]a[-2,2]t";
//	char p[M]="t[-2,2]c[-2,2]a[-2,2]t[-2,2]c";
//	char p[M]="g[-1,5]t[0,6]a[-2,7]g[-3,9]t[-2,5]a[-4,9]g[-1,8]t[-2,9]a";
//	char p[M]="g[-1,9]t[-1,9]a[-1,9]g[-1,9]t[-1,9]a[-1,9]g[-1,9]t[-1,9]a[-1,9]g[-1,9]t";
//	char p[M]="g[-1,5]t[0,6]a[-2,7]g[-3,9]t[-2,5]a[-4,9]g[-1,8]t[-2,9]a[-1,9]g[-1,9]t";
//	char p[M]="g[-1,7]t[-1,7]a[-1,7]g[-1,7]t[-1,7]a[-1,7]g";
	char p[M]="g[-1,9]t[-1,9]a[-1,9]g[-1,9]t[-1,9]a[-1,9]g";
	convert_p_to_ruler(p);
	cout<<"The pattern can written as follows:\n";
	disp_pattern();
	cout<<p<<endl;
//	int minlen,maxlen;	
//	cout<<"Please input minlen and maxlen:";
//	cin>>minlen>>maxlen;
	char fsn[]="./DataSet/AB038490.txt";
	Inputstr(fsn,S);

	DWORD begintime=GetTickCount();
//	for(int t=0;t<20;t++)
//	{
		nonoverlength();
//	}
	DWORD endtime=GetTickCount();
//	for (int i=0;i<store.size ();i++)
//		displayocc(store[i]);
//	cout <<"��ʱ"<<(endtime-begintime)/20.0<<"ms. \n";
    cout <<"��ʱ"<<endtime-begintime<<"ms. \n";
	cout <<"����"<<store.size ()<<"������\n";

}