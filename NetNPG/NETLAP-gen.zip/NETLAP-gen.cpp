//NETLAP-LENGTH �Կ��Է��ʵĺ��ӽ��������Ƿ�Ϊ��ʹ�ý��
#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <fstream>
using namespace std;
struct node
{
	int name;
	int min_root,max_root;
	vector <int> parent;
	vector <int> children;
	//int *parent,pn;
	//int *children,pc;
	bool used;
	bool toroot;//�ִ�����
	//bool toleave;//�ִ���Ҷ
};
#define N 200000
#define M 1000
char S[N];
struct sub_ptn_struct
{
	char start,end;		//
	int min,max;		//
};
struct occurrence
{
	vector <int > position;
};
vector <occurrence> store;
sub_ptn_struct sub_ptn[M];  //pattern p[i]
int ptn_len=0;  //the length of pattern
int seq_len=0;
int maxgap=-1;

void dealrange(char *p,int len)      
//put sub-pattern "a[1,3]b" into sub_ptn and sub_ptn.start=a��sub_ptn.end=b, sub_ptn.min=1��sub_ptn.max=3
{
	sub_ptn[ptn_len].start =p[0];
	sub_ptn[ptn_len].end =p[len];
	if (len==1)
	{
		sub_ptn[ptn_len].max =sub_ptn[ptn_len].min=0;
	}
	else
	{
		int value=0;
		int i;
		int flag=0;
		for (i=2;p[i]!=',';i++)
	    	if(p[i]=='-')
				flag=1;
		    else
		        value=value*10+p[i]-48;
	 	    if(flag==1)
		        sub_ptn[ptn_len].min=-value;
		    else
			    sub_ptn[ptn_len].min=value;
		    flag=0;
		    value=0;
		    for (int j=i+1;p[j]!=']';j++)
			     if(p[j]=='-')
			          flag=1;
			     else
				     value=value*10+p[j]-48;
			     if(flag==1)
				     sub_ptn[ptn_len].max=-value;
			     else
				     sub_ptn[ptn_len].max=value;
	}
	if (sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1>maxgap)
		maxgap=sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1;
	ptn_len++;
}


//find the first position of cand in the level of freArr by binary search
void convert_p_to_ruler(char *p)     //transform p into sub_ptn
{
	char st,en;
	int l,r ;
	int len=strlen(p);
	st=p[0];
	en=p[len-1];
	if (isalpha(st) && isalpha(en))
	{
		l=0;
		for (int i=1;i<len;i++)
		{
			if (isalpha(p[i]))
			{
				r=i;
				dealrange(p+l,r-l);
				l=i;
			}
		}
	}
	else
	{
		cout<<"irregular pattern.\n";
		exit(-1);
	}
}
void disp_pattern()         //display the array sub_ptn
{
	for (int i=0;i<ptn_len;i++)
	{
		//printf("%c\t%d\t%d\t%c\n",sub_ptn[i].start ,sub_ptn[i].min , sub_ptn[i].max ,sub_ptn[i].end );
		cout<<sub_ptn[i].start<<"\t"<<sub_ptn[i].min<<"\t"
			<<sub_ptn[i].max<<"\t"<<sub_ptn[i].end<<endl;
	}
}


void create_nettree(vector <node> *nettree)
{
	int *start;
	start=new int[ptn_len+1];
	int i;
	for (i=0;i<ptn_len+1;i++)
		start[i]=0;
	for(i=0;i<ptn_len+1;i++)
		nettree[i].resize(0);
	for(int j=0;j<ptn_len+1;j++)
	{
		char cchar = j == ptn_len ? sub_ptn[j-1].end : sub_ptn[j].start;
		if(j==0)
		{
			for( i=0;i<strlen(S);i++)
		    { 
				node anode;
				anode.name =i;
				anode.parent.resize (0);
				anode.children .resize (0);
				anode.max_root=anode.name;
				anode.min_root=anode.name;
				anode.used =false;
				if(cchar==S[i])
				{ 
					int len=nettree[0].size();
					nettree[0].resize(len+1);
					anode.toroot =true;
					nettree[0][len]=anode;
				}
			}
		}
		else
		{
			int p=nettree[j-1].size();
			int n=nettree[j-1][0].name;
			int m=nettree[j-1][p-1].name;
			
			if(sub_ptn[j-1].min>=0)
			{
				for(i=n+sub_ptn[j-1].min+1;i<=m+sub_ptn[j-1].max+1;i++)
				{
					node anode;
					anode.name =i;
					anode.parent.resize (0);
					anode.children .resize (0);
					anode.max_root=anode.name;
					anode.min_root=anode.name;
					anode.used =false;
				
			       if(cchar==S[i])
				   { 
				
						int len=nettree[j].size();
						nettree[j].resize(len+1);
						anode.toroot =true;
						nettree[j][len]=anode;
                        
						for(int k=start[j-1];k<p;k++)
						{
							int n=nettree[j-1][k].name;
							    if(i<n+sub_ptn[j-1].min+1)
									break;
								else if(i>n+sub_ptn[j-1].max+1)
									continue;
								else if(i>=n+sub_ptn[j-1].min+1&&i<=n+sub_ptn[j-1].max+1)
								{
								 if(n!=i)
								  {
									int nc=nettree[j-1][k].children.size();
								    nettree[j-1][k].children.resize(nc+1);
								    nettree[j-1][k].children[nc] =len;
								    int np=nettree[j][len].parent.size();
								    nettree[j][len].parent.resize(np+1);
								    nettree[j][len].parent[np]=k;
								  }
								  else
									 continue;
								}
								
						}
				   }
				}
			}		
			if(sub_ptn[j-1].max<0)
			{
				for(i=n+sub_ptn[j-1].min;i<=m+sub_ptn[j-1].max;i++)
				{
					node anode;
					anode.name =i;
					anode.parent.resize (0);
					anode.children .resize (0);
					anode.max_root=anode.name;
					anode.min_root=anode.name;
					anode.used =false;
				
			       if(cchar==S[i])
				   { 
				
						int len=nettree[j].size();
						nettree[j].resize(len+1);
						anode.toroot =true;
						nettree[j][len]=anode;
                        
						for(int k=start[j-1];k<p;k++)
						{
							int n=nettree[j-1][k].name;
							    if(i<n+sub_ptn[j-1].min)
									break;
								else if(i>n+sub_ptn[j-1].max)
									continue;
								else if(i>=n+sub_ptn[j-1].min&&i<=n+sub_ptn[j-1].max)
								{
								 if(n!=i)
								  {
									int nc=nettree[j-1][k].children.size();
								    nettree[j-1][k].children.resize(nc+1);
								    nettree[j-1][k].children[nc] =len;
								    int np=nettree[j][len].parent.size();
								    nettree[j][len].parent.resize(np+1);
								    nettree[j][len].parent[np]=k;
								  }
								  else
									 continue;
								}
								
						}
				   }
				}
			}		
			if(sub_ptn[j-1].min<0&&sub_ptn[j-1].max>=0)
			{
				for(i=n+sub_ptn[j-1].min;i<=m+sub_ptn[j-1].max+1;i++)
				{
					node anode;
					anode.name =i;
					anode.parent.resize (0);
					anode.children .resize (0);
					anode.max_root=anode.name;
					anode.min_root=anode.name;
					anode.used =false;
				
			       if(cchar==S[i])
				   { 
				
						int len=nettree[j].size();
						nettree[j].resize(len+1);
						anode.toroot =true;
						nettree[j][len]=anode;
                        
						for(int k=start[j-1];k<p;k++)
						{
							int n=nettree[j-1][k].name;
							    if(i<n+sub_ptn[j-1].min)
									break;
								else if(i>n+sub_ptn[j-1].max+1)
									continue;
								else if(i>=n+sub_ptn[j-1].min&&i<=n+sub_ptn[j-1].max+1)
								{
								  if(n!=i)
								  {
									int nc=nettree[j-1][k].children.size();
								    nettree[j-1][k].children.resize(nc+1);
								    nettree[j-1][k].children[nc] =len;
								    int np=nettree[j][len].parent.size();
								    nettree[j][len].parent.resize(np+1);
								    nettree[j][len].parent[np]=k;
								  }
								  else
									 continue;
								}
								
						}
				   }
				}
			
			}
         }		
   	}
}




void displaynettree(vector <node> *nettree)
{
    cout<<"The nettree is as follow:\n";
	cout<<"--------------------------------------------------------------------------\n";
	for (int i=0;i<ptn_len+1;i++)
	{
		cout << i <<" level:  ";
		for (int j=0;j<nettree[i].size ();j++)
			if (nettree[i][j].used ==false)
			if (nettree[i][j].used ==false)
			{
				cout <<nettree[i][j].name <<"\t";
			    cout <<nettree[i][j].name <<".max_root="<< nettree[i][j].max_root <<"\t";
				cout <<nettree[i][j].name <<".min_root="<< nettree[i][j].min_root <<"\t";
                cout <<nettree[i][j].name <<".parent=" << nettree[i][j].parent.size ()  <<"\t";
				cout <<nettree[i][j].name <<".toroot="<< nettree[i][j].toroot <<"\t";
		        cout <<nettree[i][j].name <<".used="<< nettree[i][j].used <<endl;
			}
				cout <<"\n";
		        cout <<endl;
	}
}
void update_nettree_root(vector <node> *nettree)
{
     for(int i=1;i<ptn_len+1;i++)
	 {
	     for(int j=0;j<nettree[i].size();j++)
		 {
		    bool flag = true;
			int size = nettree[i][j].parent.size();
			for(int k=0; k<size; k++)
			{
				int parent=nettree[i][j].parent[k];
				if(nettree[i-1][parent].toroot == true)
				{
					nettree[i][j].max_root = nettree[i-1][parent].max_root;
				//	flag=false;
				}
				if(nettree[i-1][parent].used == false)
				{
					flag=false;
				}
				
			}
            for(int h=0; h<size; h++)
			{
				int parent=nettree[i][j].parent[h];
				if(nettree[i-1][parent].toroot == true)
				{
					nettree[i][j].min_root = nettree[i-1][parent].min_root;
					break;
					
				}
			}
			nettree[i][j].used =flag;
			if(flag==true)
			{
				nettree[i][j].max_root=nettree[i][j].name;
				nettree[i][j].min_root=nettree[i][j].name;
				nettree[i][j].toroot = false;
			}

		}
	 }
 
}
void update_nettree(vector <node> *nettree)
{
	
	for (int i=ptn_len-1;i>=0;i--)
	{
		
		for(int j=nettree[i].size()-1;j>=0;j--)
		{
			bool flag=true;
			int size=nettree[i][j].children.size();
			for (int k=0;k<size;k++)
			{
				int child=nettree[i][j].children[k];
				if (nettree[i+1][child].used ==false)
				{
					flag=false;
					break;
					
				}
			}
			//For nodes that do not arrive at leave,marking for the used=true
			nettree[i][j].used =flag;
		}
	}
}

#include<stack>
struct storenode
{
	int position;
	int level;
};
void updatenettree_length_pc(vector <node> *nettree,occurrence &occin)
{
	//���㷨�����ƣ�����ȫ�����������������з�ʽ����Ӱ��Ľڵ��������
	//���и��׺��ӵĶ�����
	for (int level=0;level<ptn_len;level++)
	{
		int position=occin.position [level];		
		for (;position>=0;position--)
		{
			if (nettree[level][position].used ==false)
				break;
			//���Ӹ���
			int len=nettree[level][position].children .size ();
			for (int i=len-1;i>=0;i--)
			{
				int child=nettree[level][position].children [i];
				int ps=nettree[level+1][child].parent.size ();
				if (nettree[level+1][child].used ==true)
					continue;
				if (ps==1)//��һ��˫�ף�
				{
					//��һ��˫�׾�Ӧ�����������Ӳ�������
					//if (nettree[level+1][child].used ==false)
					//{
						nettree[level+1][child].used =true;
						nettree[level+1][child].toroot =false;
					//}
				}
				else
				{
					//���˫��
					for (int kk=ps-1;kk>=0;kk--)
					{
						int parent=nettree[level+1][child].parent [kk];
						int pn=nettree[level][parent].name ;
                        //cout << "parentname="<<pn<<"\n";

						if(nettree[level][parent].used ==false)
							break;
					}
					if (kk==-1)
					{
						nettree[level+1][child].used =true;
						nettree[level+1][child].toroot =false;
					}
				}	
			}
		}
	}	
}
int minvaleposition(int *nodenumber)
{
	int p=ptn_len;
	for (int i=p-1;i>=0;i--)
	{
		if (nodenumber[i]<=nodenumber[p])
			p=i;
	}
	return p;
}
void displayocc(occurrence &occ)
{
	//cout <<"An occurrence is:";
	cout <<"<";
	for (int i=0;i<ptn_len;i++)
		cout <<occ.position [i]<<",\t";
	cout <<occ.position [i];
	cout <<">"<<endl;
}
void displaychild(vector <node> *nettree)
{
	cout <<"--------child----------------\n";
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size ();j++)
		{
			//if (nettree[i][j].LPN >0)
			{
				//�Բ��ִܵ���Ҷ��Ľ�㲻����ʾ
				cout <<nettree[i][j].children .size ()  <<"\t";
			}
		}
		cout <<endl;
	}
}

//version 1  ������Ҷ�Ӳ������
void nonoverlength()
{
	
	vector <node> *nettree;
	nettree=new vector <node> [ptn_len+1];
	int *nodenumber;
	nodenumber=new int [ptn_len+1];
	create_nettree(nettree);
	//displaynettree(nettree);
	update_nettree_root(nettree);
//	update_nettree(nettree);
//	displaynettree(nettree);
//	cout <<"-------------------\n";

	store.resize (0);
	for (int position=nettree[ptn_len].size()-1;position>=0;position--)
	{
		
		if (nettree[ptn_len][position].toroot ==false)
		{
			//Ϊ�ٱ�ʾ���ִܵ����
			continue;
		}
		int leaf=nettree[ptn_len][position].name;

		//��������
		occurrence occ;
		occurrence occin;//�������е�λ�ã�
 		occ.position .resize (ptn_len+1);
		occin.position .resize (ptn_len+1);
		occin.position [ptn_len]=position;
		occ.position [ptn_len]=nettree[ptn_len][position].name;
		nettree[ptn_len][position].used =true;
		nettree[ptn_len][position].toroot =false;
		for (int j=ptn_len-1;j>=0;j--)
		{
		    int child=occin.position[j+1];    //The position of the parent in nettree
			int ps=nettree[j+1][child].parent.size ();   //The number of children of the current node
 			for (int t=ps-1;t>=0;t--)
			{
			    int parent=nettree[j+1][child].parent[t];    //The position of the most left child
				
				int nodename=nettree[j][parent].name;
				if(nettree[j][parent].used == true)
				{
				      continue;
				}
				if(nettree[j][parent].used == false)
				{
	
                       occin.position[j]=parent;			
						nettree[j][parent].used=true;
						occ.position[j]=nodename;
						nettree[j][parent].toroot =false;
						break;
				}
		
					
				
			}   
			if (t==-1)
			{
				for (int kk=j;kk<ptn_len;kk++)
				{
					int pos=occin.position [kk];
					nettree[kk][pos].used=false;
					nettree[kk][pos].toroot =true;
				}
				break;
			}
			
			
		}
		if (j==-1)
		{
				int len=store.size ();
				store.resize (len+1);
				store[len]=occ;
				updatenettree_length_pc(nettree,occin);
		}
	}
	delete []nettree;
}

void Inputstr(char *fn,char *str)
{
	FILE* fp=fopen(fn,"r+");
	if (NULL==fp)
	{
		cout<<"Cannot find the file.\n";
		return;
	}
	fseek(fp,0,SEEK_END); 
	int len =ftell(fp);
	fseek(fp,0,0); 
	fscanf(fp, "%s",str);
}

void main()
{
//   char p[M]="t[-2,2]c[-2,2]a";
//	char p[M]="a[-5,6]c[-4,7]g[-3,8]t";
//    char p[M]="a[-2,4]b[-1,1]c[-1,2]d";
//char p[M]="a[0,6]c[-1,3]t[-2,2]a";
	
 //     strcpy(S,"aactggcgcgagtcgcaatt");
	//atggactccaacaccat////gtcaagctttcaggtagac
	char p[M]="c[-1,2]a[-2,3]c[-3,4]g";
//	char p[M]="g[1,2]t[0,3]c[-3,4]g";
//	char p[M]="t[-2,2]c[-2,2]a[-2,2]t";
//	char p[M]="t[-2,2]c[-2,2]a[-2,2]t[-2,2]c";
//	char p[M]="g[-1,5]t[0,6]a[-2,7]g[-3,9]t[-2,5]a[-4,9]g[-1,8]t[-2,9]a";
//	char p[M]="g[-1,9]t[-1,9]a[-1,9]g[-1,9]t[-1,9]a[-1,9]g[-1,9]t[-1,9]a[-1,9]g[-1,9]t";
//	char p[M]="g[-1,5]t[0,6]a[-2,7]g[-3,9]t[-2,5]a[-4,9]g[-1,8]t[-2,9]a[-1,9]g[-1,9]t";
//	char p[M]="g[-1,7]t[-1,7]a[-1,7]g[-1,7]t[-1,7]a[-1,7]g";
//	char p[M]="g[-1,9]t[-1,9]a[-1,9]g[-1,9]t[-1,9]a[-1,9]g";
	convert_p_to_ruler(p);
	cout<<"The pattern can written as follows:\n";
	disp_pattern();
	cout<<p<<endl;
//	int minlen,maxlen;	
//	cout<<"Please input minlen and maxlen:";
//	cin>>minlen>>maxlen;
	char fsn[]="./DataSet/AB038490.txt";
	Inputstr(fsn,S);

	DWORD begintime=GetTickCount();
//	for(int t=0;t<20;t++)
//	{
		nonoverlength();
//	}
	DWORD endtime=GetTickCount();
//	for (int i=0;i<store.size ();i++)
//		displayocc(store[i]);
//	cout <<"��ʱ"<<(endtime-begintime)/20.0<<"ms. \n";
    cout <<"��ʱ"<<endtime-begintime<<"ms. \n";
	cout <<"����"<<store.size ()<<"������\n";

}